function [ x ] = convertSlopeToDistribution( fx, T, W, s, sWindowSum)
%input fx is a slopes of [-1, 1], output is every window's sampling
%distribution

Tx=T-W+1;

x(1:Tx*W,1) = 0;

for i=1:Tx
    a = 2*fx(i)/sWindowSum(i)/sWindowSum(i);
    b = (1-fx(i))/sWindowSum(i);
    right = 0;
    for j=1:W
        left = right;
        right = left + s(i+j-1);
        x((i-1)*W +j ) = (a * (left+right) / 2 + b)*s(i+j-1);
    end
end

end
